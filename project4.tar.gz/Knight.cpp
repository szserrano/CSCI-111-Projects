//Made by Sydney Serrano
//Knight.cpp
#include "Knight.h"
#include "Weapon.h"
#include "Random.h"

Knight::Knight(string nm, int stam, string sample, int hp, int sd) 
  : name(nm), stamina(stam), onHorse(true), F(sample, hp, sd)
{
}

bool Knight::attack()
{
  bool hit;
  hit = F.did_I_hit();
  int depletion = F.what_is_stamina_cost();
  stamina -= depletion;
  if (stamina > 0 && onHorse == true && hit == false)
  {
    cout << name << " is not exhausted (stamina = " << stamina << ") and is still on the horse." << endl;
    cout << name << " is using: ";
    F.display();
  }
  else if (stamina <= 0)
  {
    onHorse = false;
    cout << name << " is too exhausted (stamina = " << stamina << ") and has fallen off the horse." << endl;
  }
  return hit;
}

bool Knight::stam_check(){
  if (stamina > 0)
    return true;
  else 
    return false;
}

bool Knight::check_horse(){
  if (onHorse == true)
    return true;
  else 
    return false;
}

bool Knight::unhorse(){
  cout << name << " has been hit off their horse!" << endl;
  onHorse = false;
  return onHorse;
}

void Knight::display(){
  cout << "Name: " << name << endl;
  cout << "Stamina: " << stamina << endl;
  cout << name << " wields a ";
  F.display();
  cout << endl;
}

void Knight::win_joust(){
  cout << name << " has won the joust!" << endl;
}
