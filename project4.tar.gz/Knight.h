//Made by Sydney Serrano
//Knight.h
#ifndef KNIGHT_H
#define KNIGHT_H
#include <iostream>
#include "Weapon.h"
#include "Random.h"
using namespace std;

class Knight {
  private:
    string name;
    int stamina;
    bool onHorse;
    Weapon F;
  public:
    Knight(string nm, int stam, string sample, int hp, int sd); 
    bool attack();
    bool stam_check();
    bool check_horse();
    bool unhorse();
    void display();
    void win_joust();
};
#endif
