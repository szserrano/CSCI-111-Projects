//Made by Sydney Serrano
//Weapon.h
#ifndef WEAPON_H
#define WEAPON_H
#include <iostream>
using namespace std;

class Weapon {
  public:
    Weapon(string name, int hP, int sD);
    void display();
    int what_is_stamina_cost();
    bool did_I_hit();
  private:
    int hit_probability;
    int stamina_depletion;
    string type;
};
#endif
