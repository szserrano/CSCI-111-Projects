#include "Knight.h"
#include "Random.h"
#include "Weapon.h"

int main()
{ 
  string name;
  int stamina;
  bool horse;
  string type;
  int hp;
  int sd;

  cout << "\nWhat is the name of the first knight?\n";
  cin >> name;
  cout << "How much stamina does the first knight have?\n";
  cin >> stamina;
  cout << "What is the name of the weapon the first knight is wielding?\n";
  cin >> type;
  cout << "What is the chance that the weapon has to hit the other knight?\n";
  cin >> hp;
  cout << "How much stamina does the weapon consume after each use?\n";
  cin >> sd;

  Knight A(name, stamina, type, hp, sd);

  cout << "\nWhat is the name of the second knight?\n";
  cin >> name;
  cout << "How much stamina does the second knight have?\n";
  cin >> stamina;
  cout << "What is the name of the weapon the second knight is wielding?\n";
  cin >> type;
  cout << "What is the chance that the weapon has to hit the other knight?\n";
  cin >> hp;
  cout << "How much stamina does the weapon consume after each use?\n";
  cin >> sd;

  Knight B(name, stamina, type, hp, sd);

  cout << endl;
  A.display();
  B.display();

  bool a, b, c, d;
  do{
    a = A.stam_check();
    b = A.check_horse();

    c = B.stam_check();
    d = B.check_horse();
    if (a,b,c,d == true)
    {
      cout << "It is time to begin this jousting round!" << endl;
      bool h = A.attack();
      bool k = B.attack();
      if(h == true)
      {
        d = B.unhorse();
      }
      else if (k == true)
      {
        b = A.unhorse();
      }
      cout << endl;
    }
  }while(a && b && c && d == true);
  if (a == false)
    B.win_joust();
  else if (b == false)
    B.win_joust();
  else if (c == false)
    A.win_joust();
  else if (d == false)
    A.win_joust();
  return 0;
}
