//Made by Sydney Serrano
//Weapon.cpp
#include "Knight.h"
#include "Weapon.h"
#include "Random.h"

Weapon::Weapon(string name, int hP, int sD)
  : hit_probability(hP), stamina_depletion(sD), type(name)
{
}

void Weapon::display(){
  cout << type << " that costs " << stamina_depletion << " stamina and has a " << hit_probability << "% chance to hit." << endl;
}

int Weapon::what_is_stamina_cost(){
  return stamina_depletion;
}

bool Weapon::did_I_hit(){
  Random roll(1,100);
  int chance;
  chance = roll.get();
  if (hit_probability >= chance)
    return true;
  else
    return false;
}
